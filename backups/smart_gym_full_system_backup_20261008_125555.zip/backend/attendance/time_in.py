from db.connection import execute_query
from datetime import datetime
import requests
import threading


# ==========================
# BACKGROUND WEBSITE NOTIFY
# ==========================
def notify_website():
    try:
        requests.post(
            "https://smartgym-api-ia2e.onrender.com/api/notify/attendance",
            timeout=1
        )
    except:
        pass
    
# ==========================
# CLOUD SYNC
# ==========================
# ==========================
# CLOUD SYNC
# ==========================
def sync_attendance_cloud(user_id, time_in):

    try:

        response = requests.post(
            "https://smartgym-api-ia2e.onrender.com/api/sync_attendance",
            json={
                "user_id": user_id,
                "time_in": time_in.strftime("%Y-%m-%d %H:%M:%S"),
                "status": "ACTIVE"
            },
            timeout=3
        )

        if response.status_code == 200:
            print(
                f"☁️ ATTENDANCE SYNCED: "
                f"{user_id} | {time_in}"
            )
        else:
            print(
                f"☁️ ATTENDANCE SYNC FAILED: "
                f"{response.status_code}"
            )

    except Exception as e:

        print(
            "SYNC ATTENDANCE ERROR:",
            e
        )

# ==========================
# CHECK ONLY (FAST VERSION)
# ==========================
def check_time_in(user_id):

    now = datetime.now()

    # ==========================
    # MEMBER CHECK
    # ==========================
    member = execute_query(
        """
        SELECT membership_expires, monthly_expires
        FROM members
        WHERE id = %s
        """,
        (user_id,),
        fetch=True
    )

    if member:

        member = member[0]

        # already inside
        active = execute_query(
            """
            SELECT *
            FROM attendance_sessions
            WHERE user_id = %s
            AND time_out IS NULL
            LIMIT 1
            """,
            (user_id,),
            fetch=True
        )

        if active:
            return {
                "allowed": False,
                "reason": "ALREADY_INSIDE"
            }

        # yearly membership
        if (
            member["membership_expires"]
            and member["membership_expires"] > now
        ):
            return {
                "allowed": True,
                "reason": "VALID_MEMBER"
            }

        # monthly membership
        if (
            member["monthly_expires"]
            and member["monthly_expires"] > now
        ):
            return {
                "allowed": True,
                "reason": "VALID_MEMBER"
            }

        return {
            "allowed": False,
            "reason": "NO_VALID_PAYMENT"
        }

    # ==========================
    # WALKIN CHECK
    # ==========================
    
    walkin = execute_query(
        """
        SELECT id
        FROM walkins
        WHERE id = %s
        """,
        (user_id,),
        fetch=True
    )

    if walkin:

        
        payment = execute_query(
            """
            SELECT id
            FROM payments
            WHERE user_id = %s
            AND payment_type = 'WALKIN'
            AND DATE(paid_at) = CURDATE()
            LIMIT 1
            """,
            (user_id,),
            fetch=True
        )

        if not payment:
            return {
                "allowed": False,
                "reason": "WALKIN_EXPIRED"
            }

        
        active = execute_query(
            """
            SELECT session_id
            FROM attendance_sessions
            WHERE user_id = %s
            AND time_out IS NULL
            LIMIT 1
            """,
            (user_id,),
            fetch=True
        )

        if active:
            return {
                "allowed": False,
                "reason": "ALREADY_INSIDE"
            }

        return {
            "allowed": True,
            "reason": "VALID_WALKIN"
        }

    return {
        "allowed": False,
        "reason": "USER_NOT_FOUND"
    }


# ==========================
# SAVE ONLY (BACKGROUND SAFE)
# ==========================
def save_time_in(user_id):

    now = datetime.now()

    # attendance session
    execute_query(
        """
        INSERT INTO attendance_sessions
        (user_id, time_in, status)
        VALUES (%s, %s, %s)
        """,
        (user_id, now, "ACTIVE")
    )

    # access logs
    execute_query(
        """
        INSERT INTO access_logs
        (user_id, direction, result, reason)
        VALUES (%s,%s,%s,%s)
        """,
        (user_id, "IN", "ALLOW", "VALID")
    )

    # ==========================
    # WEBSITE UPDATE (BACKGROUND)
    # ==========================
    threading.Thread(
        target=sync_attendance_cloud,
        args=(user_id, now),
        daemon=True
    ).start()
    